$(document).ready(function() {

    $("#zoom").loupe({
        width: 300, // width of magnifier
        height: 300, // height of magnifier
        loupe: 'loupe' // css class for magnifier
    });

});