<?php

/**
 * Created by PhpStorm.
 * User: Muratis
 * Date: 25.09.2017
 * Time: 21:49
 */
interface BaseControllerInterface
{

}