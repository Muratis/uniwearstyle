<link rel="stylesheet" href="/css/forms/checkbox_admin.css">
<h4>
    Укажите размеры
</h4>
<div class="checkboxes">

    <label for="size">XS</label>
    <input type="checkbox" name="sizes[]" value="1" >

    <label for="size">S</label>
    <input type="checkbox" name="sizes[]" value="2">

    <label for="size">M</label>
    <input type="checkbox" name="sizes[]" value="3">

    <label for="size">L</label>
    <input type="checkbox" name="sizes[]" value="4">

    <label for="size">XL</label>
    <input type="checkbox" name="sizes[]" value="5">

    <label for="size">XXL</label>
    <input type="checkbox" name="sizes[]" value="6">

    <label for="size">XXXL</label>
    <input type="checkbox" name="sizes[]" value="7">

</div>