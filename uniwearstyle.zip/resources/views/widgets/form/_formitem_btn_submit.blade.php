{{--{!! Form::submit($title, array('class' => 'btn btn-lg btn-primary btn-block')) !!}--}}
<input type="submit" value="{{$title}}" class="btn btn-lg btn-primary btn-block">