<div class="row omb_row-sm-offset-3 omb_socialButtons">
    <div class="col-xs-4 col-sm-2">
        <a href="{{URL::to('/signin?network=facebook')}}" class="btn btn-lg btn-block omb_btn-facebook">
            <i class="fa fa-facebook visible-xs"></i>
            <span class="hidden-xs">Facebook</span>
        </a>
    </div>
    <div class="col-xs-4 col-sm-2">
        <a href="{{URL::to('/signin?network=google')}}" class="btn btn-lg btn-block omb_btn-google">
            <i class="fa fa-google-plus visible-xs"></i>
            <span class="hidden-xs">Google+</span>
        </a>
    </div>
    <div class="col-xs-4 col-sm-2">
        <a href="{{URL::to('/signin?network=vkontakte')}}" class="btn btn-lg btn-block omb_btn-vkontakte">
            <i class="fa fa-vk visible-xs"></i>
            <span class="hidden-xs">VKontakte</span>
        </a>
    </div>
</div>