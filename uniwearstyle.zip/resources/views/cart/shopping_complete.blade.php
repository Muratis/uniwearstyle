@extends('layouts/layout')


@section('content')

    <h2 class="wrapper">Благодарим за покупку, вам позвонят в ближайщее время, для подтверждения заказа</h2>

@stop