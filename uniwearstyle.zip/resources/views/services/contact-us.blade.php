@extends('layouts.layout')

@section('head_extra')

@stop

@section('content')



@stop