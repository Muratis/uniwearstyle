Для активации аккаунта пройдите по
<a href="{{ URL::to("activate/{$sentuser->getUserId()}/{$code}")
 }}">ссылке</a>
