<div class="article item">
    <a href="/{{$university[1]}}/article/{{$article->article_id}}">
        <div class="nameArticle">
            <h1 class="wrapper">{{$article->title}}</h1>
            {{--<a href="" class="wrapper">{{$article->title}}</a>--}}
        </div>
        <div class=" imgs">
            <img src="/{{$article->image}}" class="wrapper">
        </div>
    </a>

</div>