<?php
$images = $cataloge->image;
$image = explode(',', $images);

?>



<div class="item_tshirt ">
    <div>
        <a href="/<?php echo e($university); ?>/one/<?php echo e($cataloge->tshirt_id); ?>"><img src="/<?php echo e($image[0]); ?>"><?php echo e($cataloge->name); ?></a>
        <p><?php echo e($cataloge->price); ?> грн</p>
    </div>
</div>

