<div class="links-row" <?php echo $attributes; ?>>
    <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <a  <?php echo $link->attributes(); ?> href="<?php echo $link->getUrl(); ?>"><?php echo $link->getTitle(); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
