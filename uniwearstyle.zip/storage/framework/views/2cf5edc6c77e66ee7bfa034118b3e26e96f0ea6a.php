<?php
$images = $cataloge->image;
$image = explode(',', $images);
$item_id = $university[2].'_id';
?>




<div class="item_tshirt ">
    <div>
        <a href="/<?php echo e($university[1]); ?>/<?php echo e($university[2]); ?>/one/<?php echo e($cataloge->$item_id); ?>"><img src="/<?php echo e($image[0]); ?>"><?php echo e($cataloge->name); ?></a>
        <p><?php echo e($cataloge->price); ?> грн</p>
    </div>
</div>

