<?php $__env->startSection('head_extra'); ?>
    <link rel="stylesheet" href="/css/catalog/cart/checkout.css">
    <script language="javascript" src="/js/cart/cart.js"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-left'); ?>
<form action="/cart/add" method="post">
    <h4>Оформление заказа</h4>

        <div class="form-row" id="form">
            <div class="col-xs-6"><input type="text" class="form-control" placeholder="Введите имя"></div>
            <div class="col-xs-6"><input type="text" class="form-control" placeholder="Введите фамилию"></div>

            <div>
                <label for="shipping">Выберите способ доставки</label>
                <select class="form-control" name="shipping">
                    <option value="new">Отправка "Нова пошта"</option>
                    <option value="ad">Доставка на адресс</option>
                </select>
            </div>

                <div class="col-xs-5"><input type="text" class="form-control" placeholder="Город"></div>
                <div class="col-xs-5"><input type="text" class="form-control" placeholder="Адресс"></div>
                <div class="col-xs-2"><input type="text" class="form-control" placeholder="Номер дома/подьезда"></div>

                 <div class=""><input type="text" class="form-control" placeholder="Введите номер телефона"></div>
        </div>

    <?php echo e(csrf_field()); ?>

        <input type="submit" class="btn btn-success">


</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-right'); ?>

    <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="row shopItem">
            <img src="/<?php echo e($cart->options->image); ?>">
            <div>
                <p><?php echo e($cart->name); ?></p>
                <p>Размер: <?php echo e($cart->options->size); ?></p>
            </div>
            <span id="price"><?php echo e($cart->price); ?> грн</span>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


    <div class="total">
        <span>За все</span>
        <span><?php echo e(Cart::subtotal()); ?> грн</span>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layoutCart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>