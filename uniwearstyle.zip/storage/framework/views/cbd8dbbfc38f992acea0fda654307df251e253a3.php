<?php $__env->startSection('head_extra'); ?>
    <link rel="stylesheet" href="/css/catalog/catalog.css">
    <script language="javascript" src="/js/cataloge/sort.js"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('uniwear'); ?>
    <?php echo e(strtoupper($university[1])); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="wrapper btnToMainAndCatalog">
        <a href="/<?php echo e($university[1]); ?>/main" class="btn ">Главная</a>
        <a href="/<?php echo e($university[1]); ?>/tshirt" class="btn disabled">Каталог</a>

    </div>

    <div class="container cataloge">

        <div class="filter" >
            <div>
                <a  class="off-product"><i class="fa fa-sort-up"></i>Продукт</a>
                <a  class="on-product"><i class="fa fa-sort-down"></i>Продукт</a>
                <div class="product">
                    <ul class="nav ">
                        <li>
                            <button id="all" class="btn">Все</button>
                        </li>

                        <li>
                            <button  id="tshirts" class="btn">Футболки</button>
                        </li>

                        <li>
                            <button  id="polo" class="btn">Поло</button>
                        </li>

                        <li>
                            <button id="hoodie" class="btn">Худи</button>
                        </li>

                        <li>
                            <button id="sweatshirts" class="btn">Свитшоты</button>
                        </li>

                        <li>
                            <button id="bombers" class="btn">Бомберы</button>
                        </li>
                    </ul>
                </div>
                <hr>
            </div>

            <div>
                <a  class="off-sizes"><i class="fa fa-sort-up"></i>Размеры</a>
                <a  class="on-sizes"><i class="fa fa-sort-down"></i>Размеры</a>

                <div class="sizes_product">
                    <ul class="nav">

                        <li>
                            <a href="#" class="srt" >XS</a>
                            <input type="hidden" id="sr" value="1">
                        </li>

                        <li>
                            <a href="#"  >S</a>
                            <input type="hidden"  value="2">
                        </li>

                        <li>
                            <a href="#">M</a>
                        </li>

                        <li>
                            <a href="#" >L</a>
                        </li>

                        <li>
                            <a href="#">XL</a>
                        </li>
                    </ul>
                </div>
                <hr>

            </div>

        </div>


        <div class="content">
            <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cataloge): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <?php echo $__env->make('/cataloge/preview/item', array('cataloge' => $cataloge, 'university' => $university), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                
                    
                        
                    

                
        </div>



    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>