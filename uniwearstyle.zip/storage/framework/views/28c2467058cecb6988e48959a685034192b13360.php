<div class="article item">
    <a href="/<?php echo e($university[1]); ?>/article/<?php echo e($article->article_id); ?>">
        <div class="nameArticle">
            <h1 class="wrapper"><?php echo e($article->title); ?></h1>
            
        </div>
        <div class=" imgs">
            <img src="/<?php echo e($article->image); ?>" class="wrapper">
        </div>
    </a>

</div>