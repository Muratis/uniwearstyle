<?php $__env->startSection('head_extra'); ?>
    <link rel="stylesheet" href="/css/articles.css">
    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('uniwear'); ?>
    <?php echo e(strtoupper($university[1])); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container bd-shadow">
    <div class="wrapper titleArt">
        <h1><?php echo e($article->title); ?></h1>
    </div>
    <div class="content">
        <?php echo $article->text; ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>