<?php $__env->startSection('head_extra'); ?>


    <link rel="stylesheet" href="/css/catalog/one.css">

    <script type="text/javascript" src="/js/cataloge/loupe/jquery.loupe.js"></script>
    <script language="javascript" src="/js/cataloge/loupe/loupe.js"></script>

    <script language="javascript" src="/js/cart/cart.js"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div class="container info">
    <div class="images">
        <?php
        $images = $tshirt->image;
        $image = explode(',', $images);

        ?>
        <div class="main-image" >

                <?php if(isset($image[0])): ?> <img src="/<?php echo e($image[0]); ?>" id="zoom" > <?php endif; ?>

        </div>

        <div class="additional_image">
            <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <img src="/<?php echo e($item); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

        </div>

    </div>

    <div class="infoTshirt">
        <div>
            <h2 id="tshirt_name"><?php echo e($tshirt->name); ?></h2>
            <h4>KPI Style</h4>
            <h3><?php echo e($tshirt->price); ?> грн</h3>
        </div>

        <div class="size_catalog">
            

                <label for="size">Выберите размер</label>
                <select class="form-control" name="size">
                    <option value="1">XS</option>
                    <option value="2">S</option>
                    <option value="3">M</option>
                    <option value="4">L</option>
                    <option value="5">XL</option>
                    <option value="6">XXL</option>
                </select>

            <input type="hidden" value="<?php echo e($tshirt->tshirt_id); ?>" id="ajax-tshirt-id">
            <input type="hidden" value="<?php echo e($tshirt->name); ?>" id="ajax-tshirt-name">
            <input type="hidden" value="<?php echo e($tshirt->price); ?>" id="ajax-tshirt-price">
            <input type="hidden" value="<?php echo e($image[0]); ?>" id="ajax-tshirt-image">
            <?php echo e(csrf_field()); ?>


                
            <button type="button" class="btn btnSubmit" value="<?php echo e($tshirt->tshirt_id); ?>" id="add_cart">Добавить в корзину</button>

            

        </div>

        <div class="desc">
            
            <p><?php echo e($tshirt->description); ?></p>
        </div>
    </div>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>