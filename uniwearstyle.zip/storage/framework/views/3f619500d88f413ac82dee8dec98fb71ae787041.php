<?php echo e($value); ?> <?php echo $append; ?>

