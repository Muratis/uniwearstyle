<a href="#"
    <?php echo $attributes; ?>

    data-name="<?php echo e($name); ?>"
    data-value="<?php echo e($value); ?>"
    data-url="<?php echo e($url); ?>"
    data-type="text"
    data-pk="<?php echo e($id); ?>"
    data-mode="<?php echo e($mode); ?>"
><?php echo e($value); ?></a>

<?php echo $append; ?>


