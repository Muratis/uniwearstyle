<?php if(!empty($helpText)): ?>
    <small class="form-element-helptext"><?php echo $helpText; ?></small>
<?php endif; ?>
