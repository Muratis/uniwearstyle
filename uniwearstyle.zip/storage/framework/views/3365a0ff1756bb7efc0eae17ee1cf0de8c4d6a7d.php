<?php $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<span class="label label-info"><?php echo e($value); ?></span>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

<?php echo $append; ?>

