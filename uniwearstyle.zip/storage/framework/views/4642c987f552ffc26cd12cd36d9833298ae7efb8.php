<?php $__env->startSection('head_extra'); ?>
    <link rel="stylesheet" href="/css/catalog/cart/cart.css">
    <script language="javascript" src="/js/cart/cart.js"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="container">
        <h1 class="wrapper">Ваша корзина</h1>
        
            <table class="table">
                <thead class="table-header">
                <tr>
                    <th colspan="2" class="text-center">Продукт</th>
                    <th >Цена</th>
                    <th >Количество</th>
                    <th  >Всего</th>
                </tr>
                </thead>

                <tbody class="shoppingCart">
                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(action('TshirtController@getOneTshirt', array($cart->id))); ?>">
                                <img src="/<?php echo e($cart->options->image); ?>"></a>
                        </td>
                        <td class="info_product">
                            <div>
                                <a  class="" href="<?php echo e(action('TshirtController@getOneTshirt', array($cart->id))); ?>"><?php echo e($cart->name); ?></a>
                            </div>

                            <div>
                                <p>Размер: <?php echo e($cart->options->size); ?></p>
                            </div>

                            <div>
                                <button class="btn delete" value="<?php echo e($cart->rowId); ?>">Убрать из корзины</button>
                                    
                            </div>
                        </td>
                        <td  class="totalQty"><?php echo e($cart->price); ?> грн</td>
                        <td  class="totalQty"><?php echo e($cart->qty); ?> </td>
                        <td  class="totalQty"><?php echo e($cart->subtotal); ?> грн</td>




                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                <?php echo e(csrf_field()); ?>

                </tbody>
            </table>

            <footer class="cart_footer">
                <h2 id="cl"></h2>
                <div class="float_rigth">
                    <div class="sumshop">
                        <span>За все</span>
                        <span> <?php echo e(Cart::subtotal()); ?> грн</span>
                    </div>
                    <div class="button_cart">
                        <p>Стоимость доставки обсуждается по телефону</p>
                        <div>
                            <a href="/" class="btn">Продолжить покупки</a>
                            <input type="submit" value="Оформить заказ" class="btn">
                        </div>
                    </div>
                </div>
            </footer>
        


    </div>



    
    
    
    
    
    
    


    
    
    
    
    
    
    
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>