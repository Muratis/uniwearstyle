
<?php
        $images = $value;
        $image = explode(',', $value);
?>

<?php if( ! empty($image[0])): ?>
	<a href="<?php echo e($image[0]); ?>" data-toggle="lightbox">
		<img class="thumbnail" src="<?php echo e($image[0]); ?>" width="<?php echo e($imageWidth); ?>">
	</a>
<?php endif; ?>
<?php echo $append; ?>

